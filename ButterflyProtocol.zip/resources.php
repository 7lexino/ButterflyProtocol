<?php
  include_once("./views/pages/resources/resources.php");
?>